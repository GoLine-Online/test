/*
 * Allow for compatibility with other Select2 versions loaded by other plugins
 */
var wppbSelect2 = jQuery.fn.select2;